@extends('welcome')
@section('content')

    <div class="card">
        <div class="header">
            <h2>
                Categories <small>this section is related to view all categories that in the site...</small>
            </h2>
            <ul class="header-dropdown m-r--5">
                <li>
                    <a href="{{url('/auth/categories/create')}}" class="btn btn-primary">
                        create category
                    </a>
                </li>
            </ul>
        </div>
        <div class="body">
            <div class="container-fluid">
                @include('partial.alert')
                <div class="row">
                    @if(!empty($categories))
                        @foreach($categories as $category)
                            <div class="col-md-4 text-center">
                                <div class="panel">
                                    <div class="panel-body">
                                        <h3>{{$category->name}}</h3>
                                        <p>{{$category->description}}</p>
                                        <a class="btn btn-primary" href="{{route('categories.edit',$category->id)}}">Edit</a>
                                        <form method="post" action="{{route('categories.destroy',$category->id)}}" style="margin-top: 10px">
                                            {{csrf_field()}}
                                            {{method_field('DELETE')}}
                                            <!-- <input type="hidden" name="_method" value="DELETE"> -->
                                                <button class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        @endif
                </div>
            </div>
        </div>
    </div>
@endsection