<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partial.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .form-control{
            border: 1px solid #DDD !important;
            padding: 10px !important;
        }
    </style>
    <div class="card">
        <div class="header">
            <h2>
                Edit Category <small></small>
            </h2>
            <ul class="header-dropdown m-r--5">
                <li>
                    <a href="<?php echo e(url('/adminpanel/categories')); ?>" class="btn btn-primary">
                        view categories
                    </a>
                </li>
            </ul>
        </div>
        <div class="body">
            <form action="<?php echo e(route('categories.update',$category->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="PUT">
                <div class="form-group">
                    <input value="<?php echo e($category->name); ?>" class="form-control" name="name" type="text" placeholder="type category name">
                </div>

                <div class="form-group">
                    <input value="<?php echo e($category->description); ?>" class="form-control" name="description" type="text" placeholder="type category description">
                </div>

                <input class="btn btn-primary" type="submit" >
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sameh\Desktop\test\resources\views/editCategory.blade.php ENDPATH**/ ?>