<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="header">
            <h2>
                Categories <small>this section is related to view all categories that in the site...</small>
            </h2>
            <ul class="header-dropdown m-r--5">
                <li>
                    <a href="<?php echo e(url('/auth/categories/create')); ?>" class="btn btn-primary">
                        create category
                    </a>
                </li>
            </ul>
        </div>
        <div class="body">
            <div class="container-fluid">
                <?php echo $__env->make('partial.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row">
                    <?php if(!empty($categories)): ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 text-center">
                                <div class="panel">
                                    <div class="panel-body">
                                        <h3><?php echo e($category->name); ?></h3>
                                        <p><?php echo e($category->description); ?></p>
                                        <a class="btn btn-primary" href="<?php echo e(route('categories.edit',$category->id)); ?>">Edit</a>
                                        <form method="post" action="<?php echo e(route('categories.destroy',$category->id)); ?>" style="margin-top: 10px">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <!-- <input type="hidden" name="_method" value="DELETE"> -->
                                                <button class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sameh\Desktop\test\resources\views/categories.blade.php ENDPATH**/ ?>